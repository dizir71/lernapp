// config.js – hier trägst du einmalig deinen GitHub Token ein
const CONFIG = {
  githubUser: "dizir71",        // dein GitHub Benutzername
  repo: "lernapp",              // dein Repository
  token: "ghp_TEST"  // hier den GitHub-PAT einsetzen
};
